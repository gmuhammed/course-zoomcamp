import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split,cross_val_score, KFold
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score
from lightgbm import LGBMClassifier
import pickle
from sklearn.ensemble import RandomForestClassifier,GradientBoostingClassifier, AdaBoostClassifier
from catboost import CatBoostClassifier
from sklearn.model_selection import GridSearchCV

url = 'https://raw.githubusercontent.com/Gmuhammed/Drinking_Water_Potability/main/drinking_water_potability.csv'
df = pd.read_csv(url)

#since ph,Sulfate,Trihalomethanes normally distributed
df.ph.fillna(df.ph.mean(), inplace=True)
df.Sulfate.fillna(df.Sulfate.mean(), inplace=True)
df.Trihalomethanes.fillna(df.Trihalomethanes.mean(), inplace=True)

y = df.Potability
X = df.drop('Potability', axis=1)
X_train, X_test,y_train, y_test = train_test_split(X,y,test_size=0.2, random_state= 42 )


standardscaler = StandardScaler()
X_train = standardscaler.fit_transform(X_train)
X_test =  standardscaler.transform(X_test)

kf = KFold(n_splits = 10, shuffle=True, random_state=42)


gbc = GradientBoostingClassifier(random_state=42, criterion='friedman_mse', learning_rate=0.1,
                                 loss='deviance', max_depth=5,max_features='log2',
                                 min_samples_leaf=1,n_estimators=100, subsample=0.6)
gbc.fit(X_train, y_train)
cv_score = cross_val_score(gbc,X_test, y_test, cv=kf, scoring= 'roc_auc', n_jobs=-1)
print(f'cv_score: {np.mean(cv_score):.3f},{np.std(cv_score):.3f}')

""" Saving and loading the model"""

output_file = 'Drinking_Water_Potability_model.bin'
with open(output_file,'wb') as f_out:
  pickle.dump((standardscaler,gbc), f_out)



