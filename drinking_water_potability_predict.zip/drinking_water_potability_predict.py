from flask import Flask
import pandas as pd
import pickle

input_file = 'Drinking_Water_Potability_model.bin'
with open(input_file, rb) as file_in:
    scaler,model = pickle.load(file_in)

app= Flask('predict')

@app.route('/predict', methods= ['POST'])
def predict(sample):
    sample_df = pd.DataFrame(sample)
    sample_df =scaler.transform(sample)
    
    return model.predict(sample_df)
    
if __name__= '__main__':
    app.run(debug=True, host='0.0.0.0', port='9696')